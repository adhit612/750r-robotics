#include "vex.h"
#include <vector>

#define D_MOTOR_FL vex::PORT4
#define D_MOTOR_BL vex::PORT3
#define D_MOTOR_FR vex::PORT2
#define D_MOTOR_BR vex::PORT1